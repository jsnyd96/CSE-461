A: Andy Hong
B: John Snyder
